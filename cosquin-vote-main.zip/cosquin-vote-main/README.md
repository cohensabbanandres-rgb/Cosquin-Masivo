# cosquin-vote
cosquin-vote/
  index.html
  vote.html
  results.html
  assets/
    app.js
    styles.css
  data/
    day14.csv
    day15.csv
